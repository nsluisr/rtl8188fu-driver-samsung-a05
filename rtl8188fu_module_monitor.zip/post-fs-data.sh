#!/system/bin/sh
MODDIR=${0%/*}
insmod $MODDIR/system/lib/modules/rtl8188fu.ko
echo "[rtl8188fu] post-fs-data executed" >> /data/local/tmp/rtl_debug.log
